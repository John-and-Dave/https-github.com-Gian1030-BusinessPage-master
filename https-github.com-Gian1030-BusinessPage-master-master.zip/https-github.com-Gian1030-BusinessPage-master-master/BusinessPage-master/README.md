# My 2nd react project and first fully developed with git+github!
2nd websites in react. This page imitate business page. 

# Motivation
My main goal of this app was to learn working with git+github and develop new skills in animations. I put there some nice ideas from other webpages that I had seen and some of this animations are my ideas. 

# Tech

- <b>React</b>
- <b>Sass (.sass)</b>

# About code
Class components. For styling - Sass . Class names in camel case.

# About folder structure:
img - for store images
css - for store styles(after refactoring - sass)
css(old) - for store styles(before refactoring - css)
components - for store components
